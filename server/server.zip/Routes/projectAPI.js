/* eslint-disable no-unused-vars */
const { Router } = require("express");
const express = require("express");
const res = require("express/lib/response");
const router = express.Router();
const mongoose = require("mongoose");
const Projects = require("../models/projects");

router.route("/getall").get(async (req, resp) => {
    try {
        console.log("Route~Projects/getall");
        console.table(req.body);

        let result = await Projects.find({});

        if (result == null) {
            resp.status(201).send("No project found!");
        }
        else {
            resp.status(200).json(result);
        }

    } catch (err) {
        console.warn(err);
        resp.status(404).json("Err"); // Sending res to client some err occured.
    }
});


router.route("/get/:_id").get(async (req, resp) => {
    try {
        console.log("Route~Projects/get");
        

        // regex to check if the id is valid
        const reg = /^[0-9a-fA-F]{24}$/;
        if (!reg.test(req.params._id)) {
            resp.status(400).send("Invalid id");
        }

        let result = await Projects.findById({_id:req.params._id});
        if (result == null) {
            resp.status(201).send("Project not found");
        }
        else {
            resp.status(200).json(result);
        }
        
    } catch (err) {
        console.warn(err);
        resp.status(404).json("Err"); // Sending res to client some err occured.
    }

});


router.post('/add',async (req, resp) => {
    try {
        console.log("Route~Projects/add");    
        console.table(req.body);

        Projects.init();
        const setid = new mongoose.Types.ObjectId();

        const projectData = new Projects({
            _id: setid,
            projectTitle: req.body.projectTitle,
            projectDescription: req.body.projectDescription,
            timeLine: req.body.timeLine,
            ownerAddress: req.body.ownerAddress,
            price: req.body.price,
            technologies: req.body.technologies

        });

        let result = await projectData.save();

        if (result == null) {
            resp.status(201).send("Project not added");
        } else {
            resp.status(200).json(result);
        }
    } catch (err) {
        console.warn(err);
        resp.status(404).json("Err"); // Sending res to client some err occured.
    }
});

module.exports = router;
